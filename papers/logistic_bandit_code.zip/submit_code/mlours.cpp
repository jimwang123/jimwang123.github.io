#include <iostream>
#include <Eigen/Dense>
#include <ctime>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h> 
#include <time.h> 
#include <vector>
#include <fstream> 
#include <cstring>
#define Malloc(type,n) (type *)malloc((n)*sizeof(type))

using namespace std;
// g++ -g -Wall -fopenmp -o ./omp_pi ./omp_pi.c 
// g++ -g -Wall -fopenmp -I /path/to/eigen/ my_program.cpp -o my_program 

using Eigen::MatrixXd;
using Eigen::VectorXd;

static char *line = NULL;
static int max_line_len;

void Usage(char* prog_name) ;
void read_ii( char* thefile,  VectorXd& click_t,  vector<int>& arm_t,  vector< vector <int> >& decision_t);
void read_id( char* thefile,  VectorXd& arm_t ,  MatrixXd& decision_t);
void generate_item_fea( const vector<int>& decision_t,  const MatrixXd& armfea, MatrixXd& newfea);

static char* readline(FILE *input);
int thread_count;

int main(int argc, char* argv[]) {
        long long T, d, num;
	double scale, eta;
//	argv[1] number of threads
//	argv[2] ml1m_cplus.txt  [click arm action_set]
//	argv[3] arm_fea_cplus100.txt
//	argv[4] scale of exploration parameter
//	argv[5] scale of learning rate
//	argv[6] T
// 	argv[7] d
//	argv[8] num
//	argv[9] record.txt

	if (argc != 10) Usage(argv[0]);
	thread_count = strtol(argv[1], NULL, 10);

	scale = strtod(argv[4], NULL);
	eta   = strtod(argv[5], NULL);
	T = strtoll(argv[6], NULL, 10);
	d = strtoll(argv[7], NULL, 10);
	num = strtoll(argv[8], NULL, 10);	

	VectorXd click_t = VectorXd::Zero(T);
	vector< int > arm_t;
        vector< vector<int> > decision_t;
        read_ii( argv[2], click_t, arm_t, decision_t);

	MatrixXd armfea = MatrixXd::Zero(num,d);
	VectorXd dummy  = VectorXd::Zero(num);
	read_id( argv[3], dummy, armfea);
//------------------------------------------------------//
//	   Here begin to run the method			//
//------------------------------------------------------//

	//initialize some parameters
	double eta_t, gamma_t;
	double betas = 1.0 / (2.0*(1.0 + exp(1.0) ) );
	int dims = d;
	VectorXd w_t  =  VectorXd:: Zero(dims);

	int click  = 0;
	int steps  = 0;
	vector<int>    tmparr_click ;
	vector<double> tmparr_time  ;
	vector<double> tmparr_utime ;
	double ttt = 0;
	double qqq = 0;

	struct timeval exec_start, exec_end;
	gettimeofday(&exec_start, NULL);


	for (int t=0; t<T; t++){
		struct timeval start, end;
		gettimeofday(&start, NULL);
		eta_t   = eta* 2.0 / betas / (steps+1);
		gamma_t =  ( log( T* log (T) / 0.01 ) * 624.0 + 4.0  ) / pow(betas,2) / pow( scale*(steps+1), 2 );  

		int n = decision_t[t].size();
		VectorXd arm_s  = VectorXd::Zero(n);
		MatrixXd newfea; 
		generate_item_fea( decision_t[t], armfea, newfea);

#  pragma omp parallel for num_threads(thread_count) 
		for( int i=0; i<n; i++){
			arm_s(i) = newfea.row(i)*w_t + sqrt( gamma_t*( newfea.row(i).squaredNorm() ) );
		}
		 
		VectorXd::Index idd;
  		double max = arm_s.maxCoeff(&idd);		

		gettimeofday(&end, NULL);
		double t_t = ((end.tv_sec  - start.tv_sec) * 1000000u +  end.tv_usec - start.tv_usec) / 1.e6;

		if( decision_t[t][idd] == arm_t[t] ){
			ttt = ttt + t_t;
			gettimeofday(&start, NULL);

			int y_t = 1;
			if( click_t(t) == 0){
				y_t = -1;
			}else{
				click = click + 1;
				cout << t << " hello" << endl;
			}

			double yxw = y_t * newfea.row(idd)*w_t;
			VectorXd grad_f = -y_t * exp( -yxw ) / ( 1.0 + exp( -yxw ) )  * newfea.row(idd) ;
			
			w_t = w_t - eta_t * grad_f;
			w_t = w_t / w_t.norm();  


			gettimeofday(&end, NULL);
			double t_t = ((end.tv_sec  - start.tv_sec) * 1000000u +  end.tv_usec - start.tv_usec) / 1.e6;

			steps = steps + 1; 
			qqq = qqq + t_t;	
			ttt = ttt + t_t;

			if( steps % 100 == 0 ){
				tmparr_click.push_back(click);
				tmparr_time.push_back(ttt);
				tmparr_utime.push_back(qqq);
			}
		}
	}
	cout << " ===There=== " << endl;
	gettimeofday(&exec_end, NULL);
	double all_exec_time = ((exec_end.tv_sec  - exec_start.tv_sec) * 1000000u +  exec_end.tv_usec - exec_start.tv_usec) / 1.e6;
	cout <<" ====== all_exec_time ====== "<< all_exec_time << endl;
	//Here! ------ write to a file ------
	//click! steps! tmparr_click! tmparr_utime! tmparr_utime!  total_update_time! total_running_time
	ofstream myfile;
  	myfile.open (argv[9]);
	myfile << "This is the result whose the tune parameter: scale is " << scale <<  " parameter: learning rate is " << eta << endl;
	myfile << "-- ckicks -- " << click << "  steps -- " << steps << " CTR -- " << 1.0* click/steps << endl;

	myfile << " click_history " << " time_history " << " update_time_history " << endl;
	for (unsigned int i=0; i<tmparr_click.size(); i++){
		myfile << tmparr_click[i] << " " << tmparr_time[i] << " " << tmparr_utime[i] << endl;
	}
	myfile << "total_running_time: " << ttt << "  total_update_time: " << qqq << endl; 
	myfile.close();

}

void generate_item_fea( const vector<int>& decision_t,  const MatrixXd& armfea, MatrixXd& newfea){
	int n    = decision_t.size();
	int dims = armfea.cols();

	newfea = MatrixXd::Zero(n,dims);
#  pragma omp parallel for num_threads(thread_count) 
	for (int a=0; a< n; a++){
		newfea.row(a) = armfea.row( decision_t[a] - 1);
	}
}

void read_ii( char* thefile,  VectorXd& click_t, vector<int>& arm_t ,  vector< vector <int> >& decision_t){

	const char* filename = thefile;	
	FILE *fp = fopen(filename,"r");
	char *endptr;

	if(fp == NULL)
	{
		fprintf(stderr,"can't open input file %s\n", filename);
		exit (EXIT_FAILURE);
	}

	max_line_len = 1024;
	line = Malloc(char,max_line_len);
	int a_1 = 0;
	while(readline(fp)!=NULL)
	{
		vector<int> tmp;
		char *p = strtok(line," \t");
		click_t(a_1) = strtod(p,&endptr); 
		a_1++;				

		p = strtok(NULL," \t");
		arm_t.push_back(strtod(p,&endptr));

		while(1)
		{
			p = strtok(NULL," \t");
			if(p == NULL || *p == '\n') // check '\n' as ' ' may be after the last feature
				break;
			tmp.push_back(strtod(p,&endptr));
		}
		decision_t.push_back(tmp);
	}
}


//void read_id( char* thefile,  vector<int>& arm_t ,  vector< vector <double> >& decision_t){
void read_id( char* thefile,  VectorXd& arm_t ,  MatrixXd& decision_t){

	const char* filename = thefile;	
	FILE *fp = fopen(filename,"r");
	char *endptr;

	if(fp == NULL)
	{
		fprintf(stderr,"can't open input file %s\n", filename);
		exit (EXIT_FAILURE);
	}

	max_line_len = 1024;
	line = Malloc(char,max_line_len);

	int a_1 = 0;
	while(readline(fp)!=NULL)
	{
		vector<double> tmp;
		char *p = strtok(line," \t");
//		arm_t.push_back(strtod(p,&endptr));
		arm_t(a_1) = strtod(p,&endptr);
		int a_2 = 0;
		while(1)
		{
			p = strtok(NULL," \t");
			if(p == NULL || *p == '\n') // check '\n' as ' ' may be after the last feature
				break;
			decision_t(a_1,a_2) = strtod(p,&endptr);
			a_2++;
//			tmp.push_back(strtod(p,&endptr));
		}
//		decision_t.push_back(tmp);

		a_1++;
	}
}


static char* readline(FILE *input)
{
	int len;

	if(fgets(line,max_line_len,input) == NULL)
		return NULL;

	while(strrchr(line,'\n') == NULL)
	{
		max_line_len *= 2;
		line = (char *) realloc(line,max_line_len);
		len = (int) strlen(line);
		if(fgets(line+len,max_line_len-len,input) == NULL)
			break;
	}
	return line;
}

/*------------------------------------------------------------------
 * Function:  Usage
 * Purpose:   Print a message explaining how to run the program
 * In arg:    prog_name
 */
void Usage(char* prog_name) {
//	argv[1] number of threads
//	argv[2] ml1m_cplus.txt  [click arm action_set]
//	argv[3] arm_fea_cplus100.txt
//	argv[4] scale of exploration parameter
//	argv[5] scale of learning rate
//	argv[6] T
// 	argv[7] d
//	argv[8] num
//	argv[9] record.txt
   fprintf(stderr, "usage: %s <thread_count> <item_log.txt> <arm_fea.txt> <scale> <eta> <T> <d> <num> <record.txt>\n", prog_name);  /* Change */
   fprintf(stderr, "   thread_count is the number of threads >= 1\n");  /* Change */
   fprintf(stderr, "   T is the number of rounds in the log file\n");
   fprintf(stderr, "   d is the raw feature dimensions\n");
   fprintf(stderr, "   num is the number of arms in decision set\n");
   fprintf(stderr, "   order of feature respresentation\n");
   exit(0);
}  /* Usage */


/*
//	check decision_t
	for (int i=0; i< 5; i++){
		for( int j=0; j<decision_t[i].size();j++){
			cout<< decision_t[i][j] << " ";
		}
		cout << endl;
	}
	cout << "decision_t.size " << decision_t.size() << endl;

//	check arm_t
	for (int i=0; i< 5; i++){
		cout << arm_t[i]<<endl;
	}
	cout << "arm_t.size " << arm_t.size() << endl;

//	check userfea_t
	for (int i=0; i<5; i++){
		cout << userfea_t.row(i) <<endl;
	}
//	check click_t
	for (int i=0; i<5; i++){
		cout << click_t(i) <<endl;
	}

//	check armfea
	for (int i=0; i<5; i++){
		cout << armfea.row(i) <<endl;
	}
*/

