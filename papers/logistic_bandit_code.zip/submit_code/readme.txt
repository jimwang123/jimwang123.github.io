g++ -g -Wall -fopenmp -I /path/to/eigen/ my_program.cpp -o my_program


Example of usage:
[program=./yhours] [number of threads=10] [./item_log_cplus.txt] [./use_log_cplus.txt] [./arm_fea_cplus.txt] [scale of step size=1] [scale of confidence radius=10]  [line of the log file=4681992] [feature dimension=6] [number of arms in the decision set=50] [order of feature representation=4] [place to save the record=./yahoo_results/a.txt]
./yhours 10 ./item_log_cplus.txt ./user_log_cplus.txt ./arm_fea_cplus.txt 1 10 4681992 6 50 4 ./yahoo_results/ours_s1_e100_o4.txt


[program=./yhbase] [number of threads=10] [./item_log_cplus.txt] [./use_log_cplus.txt] [./arm_fea_cplus.txt] [scale of step size=0.1] [line of the log file=4681992] [feature dimension=6] [number of arms in the decision set=50] [order of feature representation=4] [place to save the record=./yahoo_results/a.txt]
./yhbase 10 ./item_log_cplus.txt ./user_log_cplus.txt ./arm_fea_cplus.txt 0.1 4681992 6 50 4 ./yahoo_results/base_s001_o4.txt


Format in ./item_log_cplus.txt
e.g.
46 9 14 15 16 18 22 25 26 28 29 32 34 35 37 38 43 44 46 47 50 
	The first element is the recommended item; the others are available items.

Format in ./user_log_cplus.txt
e.g.
0 1.000000 0.000012 0.000000 0.000006 0.000023 0.999958 

	The first element repesents whether a user clicks the item (1) or does not click the item (0); the others are features of the user.

Format in ./arm_fea_cplus.txt
e.g.
1 1.000000 0.245870 0.000000 0.019737 0.570151 0.164242 

	The first elemnet is item's ID; the others are features. 

----------------------------------------------------------------------------------------------------------------------------------------------

[program=./mlours] [number of threads=10] [./ml_cplus_log.txt] [./arm_fea_cplus100.txt] [scale of step size=1] [scale of confidence radius=10]  [line of the log file=306765] [feature dimension=100] [number of arms in the decision set=324] [place to save the record=./ml_results/a.txt]
>> ./mlours 10 ./ml_cplus_log.txt ./arm_fea_cplus100.txt 1 10 306765 100 324 ./ml_reults/ours_s1_e10_d100.txt

[program=./mlbase] [number of threads=10] [./ml_cplus_log.txt] [./arm_fea_cplus100.txt] [scale of step size=0.1] [line of the log file=306765] [feature dimension=100] [number of arms in the decision set=324] [place to save the record=./ml_results/a.txt]
>> ./mlbase 10 ./ml_cplus_log.txt ./arm_fea_cplus100.txt 0.1 306765 50 324 ./ml_reults/base_s01_d50.txt


Format in ./ml_cplus_log.txt
e.g. 
1 74 123 74 236 291 52 29 305 67 198 84 227 127 148 46 262 253 207 160 260 19 3 72 268 320 108 

	The first two elements are 
	[click=1 or no-click=0] [recommended item's ID (74)]; 
	the others are available items.

Format in ./arm_fea_cplus100.txt
e.g.
1 0.741042 0.781837 0.796996 0.775808 0.798598 0.746446 0.724719 0.802178 -0.00807832 -0.116285 0.212128 0.159715 -0.0524732 0.0970254 -0.000320222 -0.0063816 0.02031 -0.0376675 0.0448728 0.00758279 -0.0762001 0.0705516 -0.0250138 0.0350169 0.0682647 -0.028735 -0.0527371 0.214154 -0.0523362 0.0414571 0.124351 -0.0325141 0.00997685 -0.0137692 -0.126695 0.0561605 -0.0362554 -0.0459054 -0.111675 0.0995903 -0.0549343 0.190097 -0.083692 -0.00368949 0.0419988 0.155574 0.0288558 -0.163461 -0.0619727 0.140502 -0.00908294 -0.029264 -0.0975819 0.124474 0.12867 -0.0173272 0.0382029 -0.282342 0.151705 0.0444785 0.0406843 0.135694 -0.124589 -0.0342014 -0.103474 0.0380509 0.00645712 0.236207 0.0194122 -0.220908 -0.0529815 0.0591949 -0.0307489 0.245192 0.0171617 0.182207 0.215099 -0.082827 -0.184228 -0.0954447 0.0898803 0.0223897 0.216589 0.0634785 -0.290811 -0.0905297 0.194216 0.0471727 0.0157024 -0.101754 0.0559836 -0.00296579 -0.0311544 0.00899102 -0.0757067 0.181508 -0.125198 0.193692 0.209648 0.0315714 

	The first elemnet is item's ID; the others are features. 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-------------

There are some scripts for parsing the raw data into the required format.




