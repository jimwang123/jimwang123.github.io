#!/usr/bin/perl 

open(IN, "$ARGV[0]") || die;    #dictionary
open(ORI, "$ARGV[1]") || die;   #ori_arm_fea_file
open(OUT,">$ARGV[2]") || die;   #final_arm_fea_file
#---------------------------------------------------#
my %dict = ();

$k = 1;
while($line=<IN>){
	chomp $line;
	$dict{$line} = $k;
	$k = $k + 1;
}
close IN;


while($line=<ORI>){
	chomp $line;
	@total = split(/\s+/,$line);
	$num = scalar @total;

	print OUT "$dict{$total[0]} ";

	$j = 1;
	while( $j < $num ){
		print OUT "$total[$j] ";
		$j++;
	}
	print OUT "\n";
}
close ORI;
close OUT;
