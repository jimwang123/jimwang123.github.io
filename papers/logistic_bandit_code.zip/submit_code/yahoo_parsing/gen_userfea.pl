#!/usr/bin/perl 

open(IN,"$ARGV[0]") || die;    			#fea.txt
open(OUT, ">$ARGV[1]") || die;

my %fea = ();
while($line=<IN>){
	chomp $line;
	@total = split(/\s+/,$line);
	$num = scalar @total;

	print OUT "$total[2] $total[9] ";
	$k=4; 
	while( $k < 9 ){
		print OUT "$total[$k] ";
		$k++;
	}
	print OUT "\n";
}
close IN;
close OUT;


