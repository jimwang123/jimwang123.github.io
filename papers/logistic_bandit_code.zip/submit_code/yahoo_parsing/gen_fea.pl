#!/usr/bin/perl 

open(IN,"$ARGV[0]") || die;    			#fea.txt
open(OUT, ">$ARGV[1]") || die;

my %fea = ();
while($line=<IN>){
	chomp $line;
	@total = split(/\s+/,$line);
	$num = scalar @total;

	$j = 5;
	#print "$line :: $num\n";
	while( $j < $num){
		if (index($total[$j], "\|") != -1) {		
			#print "$total[$j] ";
			if( exists $fea{$total[$j]} ) {

			}else{
				$k = 1;
				my @arr;
				while( $k < 7 ){
					push @arr, $total[$j + $k]; 
					$k++;
				}
				#push to the dictionary
				my $strings;
				foreach $a (@arr){
					#print "$a \n";
					$strings = $strings . '_'.  $a;
				}
				$fea{$total[$j]} = $strings;
#				print "$strings\n";
			}			
		}
		$j++;
	}
}
close IN;


foreach $key (keys %fea)
{
	@tmp = split(/\_/, $fea{$key} );
	$num = scalar @tmp;
	$j = 1;
	print OUT "$key $tmp[$num-1] ";
	while( $j < $num-1 ){
		print OUT "$tmp[$j] ";
		$j++;
	}
	print OUT "\n";
}
close OUT;
