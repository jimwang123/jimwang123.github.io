#!/usr/bin/perl 

open(IN,"$ARGV[0]") || die;    			#fea.txt

$line=<IN>;
chomp $line;
@total = split(/\s+/,$line);
$peg = scalar @total;



while($line=<IN>){
	chomp $line;
	@total = split(/\s+/,$line);
	$num = scalar @total;

	print "$num \n";
	if( $peg != $num ){
		print "error $peg $num \n";
	}
}
