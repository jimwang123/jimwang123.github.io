#!/usr/bin/perl 

open(IN,"$ARGV[0]") || die;    #arm_id
$ID = $ARGV[1];


while($line=<IN>){
	chomp $line;
	@total = split(/\s+/,$line);
	$num = scalar @total;
	
	$j = 4;
	$kkk = 0;

	$peg = 0;

	while( $j < $num){
		if (index($total[$j], "\|$ID") != -1) {		
			$kkk =$j;
			print "$kkk:: ";
			$peg = 1;
			last;
		}
		$j++;
	}
	if( $peg == 1 ){
		$j = 0;
		while( $j < 6 ){
			print "$total[ $kkk + $j] ";
			$j++;
		}
		print "\n";
	}
}
close IN;


