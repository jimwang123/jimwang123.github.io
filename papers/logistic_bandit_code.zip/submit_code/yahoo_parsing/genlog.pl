#!/usr/bin/perl 

open(IN, "$ARGV[0]") || die;    #dictionary
open(LOG, "$ARGV[1]") || die;   #log
open(OUT,">$ARGV[2]") || die;   #output
#---------------------------------------------------#
my %dict = ();

$k = 1;
while($line=<IN>){
	chomp $line;
	$dict{$line} = $k;
	$k = $k + 1;
}
close IN;
#---------------------------------------------------#

while($line=<LOG>){
	chomp $line;
	@total = split(/\s+/,$line);
	$num = scalar @total;
	$j = 1;
	
	$a = "\|".$total[$j];	
	print OUT "$dict{$a} ";

	$j= 4;
	my @final;
	while( $j < $num){
		if (index($total[$j], "\|") != -1) {	
			push @final, $dict{$total[$j]}; 
		}
		$j++;
	}

	@sorted = sort { $a <=> $b } @final;
	foreach(@sorted)
	{
	    print OUT "$_:1 ";
	}
	print OUT "\n";

}
#---------------------------------------------------#
close OUT;
close LOG;
