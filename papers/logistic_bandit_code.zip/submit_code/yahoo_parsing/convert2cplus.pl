#!/usr/bin/perl 

open(IN,"$ARGV[0]") || die;    			#fea.txt
open(OUT,">$ARGV[1]") || die;

while($line=<IN>){
	chomp $line;
	@total = split(/\s+/,$line);
	$num = scalar @total;
	
	$i = 0;
	while ( $i < $num ){
		if (index($total[$i], ":") != -1) {		
			@tmp = split(/:/,$total[$i]);
			print OUT "$tmp[$ARGV[2]] ";
		}else{
			print OUT "$total[$i] ";
		}
		$i++;
	} 
		print OUT "\n";

}

close IN;
close OUT;

# parsing finished
# code of ours
# code of baseline
#-----------------------------#
# code of movieLens dataset
