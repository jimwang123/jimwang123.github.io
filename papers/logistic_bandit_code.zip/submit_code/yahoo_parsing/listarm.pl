#!/usr/bin/perl 

open(IN,"$ARGV[0]") || die;    #arm_id
open(OUT,">$ARGV[1]") || die;  #old_id new_id


my %dict = ();
$k=1;
while($line=<IN>){
	chomp $line;
	@total = split(/\s+/,$line);
	$num = scalar @total;
	
	$j = 4;
	while( $j < $num){
		if (index($total[$j], "\|") != -1) {	
			if( exists $dict{$total[$j]} ) {

			}else{
				$dict{$total[$j]} = $k;
				$k += 1;
			}			
		}
		$j++;
	}
}
close IN;

while( my( $key, $value ) = each %dict ){
    print OUT "$key\n";
}


$size = keys %dict;
print "the size: $size\n";

