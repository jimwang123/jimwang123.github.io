#!/usr/bin/perl 

open(IN,"$ARGV[0]") || die;    					#fea.txt

$click= 0;
$nl   = 0;

while($line=<IN>){
	chomp $line;
	@total = split(/\s+/,$line);

	if( $total[0] == 1){
		$click++;
	}
	$nl++;

}
$CTR = $click / $nl;

print "CTR $CTR \n";
close IN;


