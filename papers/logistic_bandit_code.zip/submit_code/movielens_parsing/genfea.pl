#!/usr/bin/perl 

open(IN,"$ARGV[0]") || die;   #arm_id
open(OUT,">$ARGV[1]") || die;

while($line=<IN>){
	chomp $line;

	@total = split(/\s+/,$line);

	@tmp = split( /q/, $total[0] );
	print OUT "$tmp[1] ";


	$num = scalar @total;
	$i=2;
	while( 	$i < $num){
		$k = $i -1;
		print OUT  "$k:$total[$i] "; 
		$i++;
	}
	print OUT "\n";

}

close IN;
close OUT;



