#!/usr/bin/perl 

open(ID,"$ARGV[0]") || die;
open(IN,"$ARGV[1]") || die;    			#fea.txt
open(OUT,">$ARGV[2]") || die;

my %id = ();
$k=1;
while($line=<ID>){
	chomp $line;
	$id{$line} = $k;
	$k++;
}

while($line=<IN>){
	chomp $line;
	@total = split(/\,/,$line);
	$num = scalar @total;
	
	print OUT "$total[0] ";
	$i = 1;
	while ( $i < $num ){
		print OUT "$id{$total[$i]} ";
		$i++;
	} 
	print OUT "\n";

}

close ID;
close IN;
close OUT;

# parsing finished
# code of ours
# code of baseline
#-----------------------------#
# code of movieLens dataset
