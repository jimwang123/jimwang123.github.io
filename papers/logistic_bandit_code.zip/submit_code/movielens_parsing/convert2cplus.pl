#!/usr/bin/perl 

open(ID,"$ARGV[0]") || die;
open(IN,"$ARGV[1]") || die;    			#fea.txt
open(OUT,">$ARGV[2]") || die;

my %id = ();
$k=1;
while($line=<ID>){
	chomp $line;
	$id{$line} = $k;
	$k++;
}

while($line=<IN>){
	chomp $line;
	@total = split(/\s+/,$line);
	$num = scalar @total;
	
	$i = 0;
	while ( $i < $num ){
		if (index($total[$i], ":") != -1) {		
			@tmp = split(/:/,$total[$i]);
			print OUT "$tmp[1] ";
		}else{
			print OUT "$id{$total[$i]} ";
		}
		$i++;
	} 
		print OUT "\n";

}

close IN;
close OUT;

# parsing finished
# code of ours
# code of baseline
#-----------------------------#
# code of movieLens dataset
