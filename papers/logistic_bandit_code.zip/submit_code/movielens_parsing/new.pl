#!/usr/bin/perl 

open(IN,"$ARGV[0]") || die;   #arm_id

while($line=<IN>){
	chomp $line;
#	print $line;
	system("grep 'q$line ' $ARGV[1]");
}
close IN;



